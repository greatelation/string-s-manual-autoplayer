import tkinter as tk
from tkinter import scrolledtext
import keyboard
import pyautogui
import time
import random

class ManualAutoplayer:
    

    QWERTY_L_KEYS = set(['`', '1', '2', '3', '4', '5', 'q', 'w', 'e', 'r', 't', 'a', 's', 'd', 'f', 'g', 'z', 'x', 'c', 'v', 'b', 
                         '!', '@', '#', '$', '%', '~', '{', '[', '|', '_', '+', ':', '"', '<', '?', '(', ')', '*', '&', '^', 'Q', 'W', 'E', 'R', 'T', 'A', 'S', 'D', 'F', 'G', 'Z', 'X', 'C', 'V', 'B'])
    QWERTY_R_KEYS = set(['6', '7', '8', '9', '0', '-', '=', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\', 'h', 'j', 'k', 'l', ';', "'", 'n', 'm', ',', '.', '/', 
                         '^', '&', '*', '(', ')', '_', '+', '}', '|', ':', '"', '<', '>', '?', 'Y', 'U', 'I', 'O', 'P', 'H', 'J', 'K', 'L', 'N', 'M'])

    MIDI_L_KEYS = set(['!', '@', '#', '$', '%', '^', '(', 'Q', 'W', 'E', 'T', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 
                       'q', 'w', 'e', 'r', 't', 'a', 's', 'd', 'f', 'g', 'z', 'x', 'c', 'v', 'b'])
    MIDI_R_KEYS = set(['&', '*', ')', 'Y', 'U', 'I', 'O', 'P', 'S', 'D', 'G', 'H', 'J', 'K', 'L', 'Z', 'C', 'V', 'B', 'y', 'u', 'i', 'o', 'p', 'h', 'j', 'k', 'l', 'n', 'm'])

    HOVER_DELAY_MS = 500
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("String's Autoplayer")
        
        window_width = 345
        window_height = 350
        screen_width = self.root.winfo_screenwidth()
        right_margin = 50 
        x_position = screen_width - window_width - right_margin 
        y_position = 50 
        self.root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

        self.root.attributes('-topmost', True)

        self.notes = []
        self.current_index = 0
        self.is_playing = False
        self.song_finished = False

        self.key_layout = tk.BooleanVar(value=False)
        self.lr_enabled = tk.BooleanVar(value=False)

        self.delay_enabled = tk.BooleanVar(value=True) # Delay is ON by default

        self.note_timestamps = []
        self.max_timestamp_count = 10

        self.held_play_keys = {}
        
        self.f1_held = False
        self.f2_held = False

        self.help_popup = None
        self.tooltip_timer = None


        control_frame = tk.Frame(self.root, bg='#2d2d2d', height=50)
        control_frame.pack(fill=tk.X, pady=5, padx=5)

        self.play_btn = tk.Button(control_frame, text="▶", font=('Arial', 16),
                                   command=self.toggle_play, bg='#4a9eff', fg='white',
                                   width=3, relief=tk.FLAT)
        self.play_btn.pack(side=tk.LEFT, padx=5)

        self.stop_btn = tk.Button(control_frame, text="■", font=('Arial', 16),
                                   command=self.stop, bg='#ff4a4a', fg='white',
                                   width=3, relief=tk.FLAT, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        self.status_label = tk.Label(control_frame, text="Stopped", 
                                     bg='#2d2d2d', fg='#808080', 
                                     font=('Arial', 11))
        self.status_label.pack(side=tk.LEFT, padx=10)
        
        self.nps_label = tk.Label(control_frame, text="0.0 NPS", 
                                 bg='#2d2d2d', fg='#4a9eff', 
                                 font=('Arial', 12, 'bold'))
        self.nps_label.pack(side=tk.RIGHT, padx=10)
        

        view_frame = tk.Frame(self.root, bg='#3d3d3d', height=50)
        view_frame.pack(fill=tk.X, padx=5, pady=5)
        view_frame.pack_propagate(False)

        self.view_text = tk.Text(view_frame, font=('Consolas', 14),
                                 bg='#3d3d3d', fg='white', height=1,
                                 wrap=tk.NONE, relief=tk.FLAT, padx=10, pady=10)
        self.view_text.pack(fill=tk.BOTH, expand=True)
        self.view_text.config(state=tk.DISABLED)
        self.view_text.tag_config('highlight', background='#4a9eff', foreground='white')

        separator = tk.Frame(self.root, height=2, bg='#555')
        separator.pack(fill=tk.X, padx=5)

        notes_frame = tk.Frame(self.root, bg='#2d2d2d', height=30)
        notes_frame.pack(fill=tk.X, padx=5, pady=(5,0))
        notes_frame.pack_propagate(False)
        
        notes_label = tk.Label(notes_frame, text="Notes:", bg='#2d2d2d',
                               fg='white', font=('Arial', 10), anchor='w')
        notes_label.pack(side=tk.LEFT, padx=5)
        
        notes_help_btn = tk.Button(notes_frame, text="?", font=('Arial', 11, 'bold'),
                                   bg='#3d3d3d', fg='white', width=2, height=1,
                                   relief=tk.FLAT, cursor='hand2', bd=0)
        notes_help_btn.pack(side=tk.LEFT, padx=(5, 10))
        notes_help_btn.bind('<Enter>', self.show_help)
        notes_help_btn.bind('<Leave>', self.hide_help)
        
        self.key_layout.trace_add('write', self.update_key_layout_visual)
        self.lr_enabled.trace_add('write', self.update_lr_visual)

        self.delay_enabled.trace_add('write', self.update_delay_visual)
        
        key_layout_frame = tk.Frame(notes_frame, bg='#2d2d2d')
        key_layout_frame.pack(side=tk.RIGHT, padx=5) 
        
        self.midi_label = tk.Label(key_layout_frame, text="midi", bg='#2d2d2d',
                                     fg='gray', font=('Arial', 10, 'bold'), cursor='hand2', padx=5)
        self.midi_label.pack(side=tk.RIGHT)
        self.midi_label.bind('<Button-1>', lambda e: self.key_layout.set(True))
        self.midi_label.bind('<Enter>', lambda e: self.schedule_tooltip(e, "key layout", self.HOVER_DELAY_MS))
        self.midi_label.bind('<Leave>', lambda e: self.unschedule_tooltip())
        
        separator_label = tk.Label(key_layout_frame, text="|", bg='#2d2d2d', fg='white', font=('Arial', 10, 'bold'))
        separator_label.pack(side=tk.RIGHT)
        
        self.qwerty_label = tk.Label(key_layout_frame, text="qwerty", bg='#2d2d2d',
                                     fg='white', font=('Arial', 10, 'bold'), cursor='hand2', padx=5)
        self.qwerty_label.pack(side=tk.RIGHT)
        self.qwerty_label.bind('<Button-1>', lambda e: self.key_layout.set(False))
        self.qwerty_label.bind('<Enter>', lambda e: self.schedule_tooltip(e, "key layout", self.HOVER_DELAY_MS))
        self.qwerty_label.bind('<Leave>', lambda e: self.unschedule_tooltip())
        

        self.delay_btn = tk.Button(key_layout_frame, text="ⴵ", font=('Arial', 10, 'bold'),
                                 command=self.toggle_delay, bg='#4a9eff', fg='white', # Set initial color for ON
                                 width=2, height=1,
                                 relief=tk.FLAT)
        self.delay_btn.pack(side=tk.RIGHT, padx=(0, 10))
        # Bind for tooltip
        self.delay_btn.bind('<Enter>', self.delay_btn_hover_enter)
        self.delay_btn.bind('<Leave>', self.delay_btn_hover_leave)
        

        self.lr_btn = tk.Button(key_layout_frame, text="LR", font=('Arial', 8, 'bold'),
                                 command=self.toggle_lr, bg='#3d3d3d', fg='#808080',
                                 width=2, height=1,
                                 relief=tk.FLAT)
        # self.lr_btn.pack(side=tk.RIGHT, padx=(0, 10)) # REMOVED: Replaced by self.delay_btn

        
        self.update_key_layout_visual()
        self.update_lr_visual()

        self.update_delay_visual()

        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD,
                                                     font=('Consolas', 11),
                                                     bg='#1e1e1e', fg='white',
                                                     insertbackground='white')
        self.text_area.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.SYMBOL_SHIFT_MAP = {
            '!': ('1', True), '@': ('2', True), '#': ('3', True), '$': ('4', True),
            '%': ('5', True), '^': ('6', True), '&': ('7', True), '*': ('8', True),
            '(': ('9', True), ')': ('0', True), '_': ('-', True), '+': ('=', True),
            '{': ('[', True), '}': (']', True), '|': ('\\', True), ':': (';', True),
            '"': ("'", True), '<': (',', True), '>': ('.', True), '?': ('/', True),
            '~': ('`', True),
            ',': (',', False), '.': ('.', False), '-': ('-', False), '=': ('=', False),
            '\\': ('\\', False), '/': ('/', False), ';': (';', False), "'": ("'", False),
            '[': ('[', False), ']': (']', False),
        }

        self.play_keys = ['+', '\\', ',']
        
        try:
            keyboard.on_press_key('f1', self.on_f1_press, suppress=False)
            keyboard.on_release_key('f1', self.on_f1_release, suppress=False)
            keyboard.on_press_key('f2', self.on_f2_press, suppress=False)
            keyboard.on_release_key('f2', self.on_f2_release, suppress=False)
            keyboard.on_press_key('ctrl', self.on_f1_press, suppress=False) 
            keyboard.on_release_key('ctrl', self.on_f1_release, suppress=False)
            keyboard.on_press_key('alt', self.on_f2_press, suppress=False)
            keyboard.on_release_key('alt', self.on_f2_release, suppress=False)
        except Exception:
            pass
    

    def toggle_delay(self):
        self.delay_enabled.set(not self.delay_enabled.get())
        
    def update_delay_visual(self, *args):
        if self.delay_enabled.get():
            self.delay_btn.config(bg='#4a9eff', fg='white') # ON: Blue
        else:
            self.delay_btn.config(bg='#3d3d3d', fg='#808080') # OFF: Gray
            
    def delay_btn_hover_enter(self, event):
        tooltip_text = "Delay enabled" if self.delay_enabled.get() else "Delay disabled"
        self.schedule_tooltip(event, tooltip_text, self.HOVER_DELAY_MS)
        
    def delay_btn_hover_leave(self, event):
        self.unschedule_tooltip()
        

        
    def on_f1_press(self, e):
        self.f1_held = True
    
    def on_f1_release(self, e):
        self.f1_held = False

    def on_f2_press(self, e):
        self.f2_held = True

    def on_f2_release(self, e):
        self.f2_held = False
    
    # Kept for compatibility, though the LR button is visually replaced by delay_btn
    def toggle_lr(self):
        self.lr_enabled.set(not self.lr_enabled.get())

    def update_lr_visual(self, *args):


        pass


    def show_help(self, event):
        if self.help_popup:
            return
        
        self.help_popup = tk.Toplevel(self.root)
        self.help_popup.wm_overrideredirect(True)

        btn_x = event.widget.winfo_rootx()
        btn_y = event.widget.winfo_rooty()
        self.help_popup.wm_geometry(f"+{btn_x + 30}+{btn_y + 30}")
        self.help_popup.attributes('-topmost', True)
        
        frame = tk.Frame(self.help_popup, bg='#2d2d2d', borderwidth=1, relief=tk.SOLID)
        frame.pack(fill=tk.BOTH, expand=True)
        
        title = tk.Label(frame, text="How to use", font=('Arial', 9, 'bold'),
                          bg='#2d2d2d', fg='white', anchor='w', padx=8, pady=5)
        title.pack(fill=tk.X)
        
        sep = tk.Frame(frame, height=1, bg='#555')
        sep.pack(fill=tk.X, padx=5)
        
        help_text = ("Paste your virtual piano sheets into the black box below\n\n"
                      "Press ▶ to start playing, and ■ to stop playing and edit\n"
                      "or change your sheets.\n\n"
                      "Play by tapping and holding either one of the + \\ , keybinds\n"
                      "- you play at your own tempo.\n\n"
                      "Press ⴵ to enable or disable delay while playing\n"
                      "- delay is enabled by default\n\n"
                      "NPS shows you roughly how fast you are playing and is\n"
                      "displayed in the top right corner")
        
        text_label = tk.Label(frame, text=help_text, font=('Arial', 8),
                              bg='#2d2d2d', fg='#cccccc', justify=tk.LEFT,
                              anchor='w', padx=8, pady=5)
        text_label.pack(fill=tk.BOTH)

    def update_key_layout_visual(self, *args):
        is_midi = self.key_layout.get()
        if is_midi:
            self.midi_label.config(fg='#4a9eff')
            self.qwerty_label.config(fg='gray')
        else:
            self.qwerty_label.config(fg='#4a9eff')
            self.midi_label.config(fg='gray')
            
    def schedule_tooltip(self, event, text, delay_ms):
        self.unschedule_tooltip()
        
        label = event.widget

        is_delay_btn = (label == self.delay_btn)
        
        is_layout_active = False
        if label in (self.qwerty_label, self.midi_label):
            is_active = (label == self.qwerty_label and not self.key_layout.get()) or \
                         (label == self.midi_label and self.key_layout.get())
            if is_active:
                is_layout_active = True
        
        if is_layout_active or label == self.lr_btn or is_delay_btn:
            self.tooltip_timer = self.root.after(delay_ms, lambda: self.show_tooltip(event, text))

    def unschedule_tooltip(self):
        if self.tooltip_timer is not None:
            self.root.after_cancel(self.tooltip_timer)
            self.tooltip_timer = None
        self.hide_tooltip()

    def show_tooltip(self, event, text):
        if self.help_popup:
            return
            
        label = event.widget
        
        is_active = True
        if label in (self.qwerty_label, self.midi_label):
            is_active = (label == self.qwerty_label and not self.key_layout.get()) or \
                         (label == self.midi_label and self.key_layout.get())
        
        if not is_active and label not in (self.delay_btn, self.lr_btn):
            return

        self.help_popup = tk.Toplevel(self.root)
        self.help_popup.wm_overrideredirect(True)
        lbl_x = label.winfo_rootx()
        lbl_y = label.winfo_rooty()
        lbl_w = label.winfo_width()
        lbl_h = label.winfo_height()
        

        if label == self.delay_btn:

            x = lbl_x + lbl_w // 2 # Center X
            y = lbl_y - 20 # Position 20 pixels above
            self.help_popup.wm_geometry(f"+{x}+{y}")

            self.help_popup.update_idletasks()
            popup_width = self.help_popup.winfo_width()
            x_centered = x - popup_width // 2
            self.help_popup.wm_geometry(f"+{x_centered}+{y}")
        else:

            x = lbl_x + lbl_w + 2
            y = lbl_y + 2
            self.help_popup.wm_geometry(f"+{x}+{y}")
        
        self.help_popup.attributes('-topmost', True)

        label_tooltip = tk.Label(self.help_popup, text=text, 
                                 bg='#3d3d3d', fg='white', 
                                 padx=5, pady=1, 
                                 font=('Arial', 7),
                                 borderwidth=1, relief=tk.SOLID)
        label_tooltip.pack()

    def hide_tooltip(self):
        if self.help_popup:
            self.help_popup.destroy()
            self.help_popup = None
            
    def hide_help(self, event):
        if self.help_popup and not self.tooltip_timer: 
            self.help_popup.destroy()
            self.help_popup = None
    
    def parse_notes(self, text):
        notes = []
        i = 0
        while i < len(text):
            if text[i] == '[':
                end = text.find(']', i)
                if end != -1:
                    content = text[i+1:end].strip()
                    content = content.replace('-', '').replace('|', '')
                    if content:
                        notes.append(content)
                    i = end + 1
                else:
                    i += 1
            elif text[i] not in ' \n\t\r[]-|':
                notes.append(text[i])
                i += 1
            else:
                i += 1
        return notes

    def update_view(self):
        if not self.is_playing or not self.notes:
            self.view_text.config(state=tk.NORMAL)
            self.view_text.delete('1.0', tk.END)
            self.view_text.config(state=tk.DISABLED)
            return

        original_text = self.text_area.get('1.0', tk.END).strip().replace('\n', ' ').replace('\r', ' ')
        played_index = (self.current_index - 1) % len(self.notes) if self.current_index > 0 else len(self.notes) - 1

        note_positions = []
        note_counter = 0
        i = 0
        while i < len(original_text):
            if original_text[i] == '[':
                end = original_text.find(']', i)
                if end != -1:
                    note_positions.append((note_counter, i, end + 1))
                    note_counter += 1
                    i = end + 1
                else:
                    i += 1
            elif original_text[i] not in '\t -|':
                note_positions.append((note_counter, i, i + 1))
                note_counter += 1
                i += 1
            else:
                i += 1

        if played_index >= len(note_positions):
            return

        text_start = note_positions[played_index][1]
        window_end = min(len(note_positions), played_index + 20)
        if window_end <= len(note_positions):
            text_end = note_positions[window_end - 1][2]
        else:
            text_end = len(original_text)
        text_end = min(len(original_text), text_end + 30)
        while text_start > 0 and original_text[text_start - 1] == ' ':
            text_start -= 1

        display_text = original_text[text_start:text_end]
        played_note_start = note_positions[played_index][1] - text_start
        played_note_end = note_positions[played_index][2] - text_start

        self.view_text.config(state=tk.NORMAL)
        self.view_text.delete('1.0', tk.END)
        self.view_text.insert('1.0', display_text)
        if 0 <= played_note_start < len(display_text):
            highlight_start = f"1.{played_note_start}"
            highlight_end = f"1.{played_note_end}"
            self.view_text.tag_add('highlight', highlight_start, highlight_end)
        self.view_text.config(state=tk.DISABLED)

    def char_to_keyinfo(self, char):
        if char in self.SYMBOL_SHIFT_MAP:
            return self.SYMBOL_SHIFT_MAP[char]
        if char.isalpha():
            return (char.lower(), char.isupper())
        if char.isdigit():
            return (char, False)
        return (char, False)

    def calculate_nps(self):
        if len(self.note_timestamps) < 2:
            return 0.0
        
        time_span = self.note_timestamps[-1] - self.note_timestamps[0]
        if time_span <= 0:
            return 0.0
        
        nps = (len(self.note_timestamps) - 1) / time_span
        return nps
    
    def update_nps_display(self):
        nps = self.calculate_nps()
        self.nps_label.config(text=f"{nps:.1f} NPS")
    
    def release_all_keys(self):
        for play_key in list(self.held_play_keys.keys()):
            try:
                self.release_held_note_for_playkey(play_key)
            except Exception:
                pass
        
        try:
            keyboard.release('shift')
        except Exception:
            pass
        try:
            pyautogui.keyUp('shift')
        except Exception:
            pass
        
        common_keys = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
                       '0','1','2','3','4','5','6','7','8','9',',','.','/','\\','[',']',';',"'",'-','=','`']
        for key in common_keys:
            try:
                keyboard.release(key)
            except Exception:
                pass
    
    def press_and_hold_note_for_playkey(self, play_key):
        if not self.is_playing or not self.notes:
            return
        if self.current_index >= len(self.notes):
            self.current_index = 0

        note = self.notes[self.current_index]
        
        if self.lr_enabled.get():
            is_qwerty = not self.key_layout.get()
            
            if is_qwerty:
                l_keys = self.QWERTY_L_KEYS
                r_keys = self.QWERTY_R_KEYS
            else:
                l_keys = self.MIDI_L_KEYS
                r_keys = self.MIDI_R_KEYS
                
            if self.f1_held:
                playable_chars = [ch for ch in note if ch != '?' and ch in l_keys]
            elif self.f2_held:
                playable_chars = [ch for ch in note if ch != '?' and ch in r_keys]
            else:
                playable_chars = [ch for ch in note if ch != '?']
        else:
            playable_chars = [ch for ch in note if ch != '?']

        pressed_list = []
        
        if not playable_chars:
            self.held_play_keys[play_key] = []
            return
        
        shift_chars = []
        normal_chars = []
        
        for ch in playable_chars:
            base, need_shift = self.char_to_keyinfo(ch)
            if need_shift:
                shift_chars.append((base, ch))
            else:
                normal_chars.append((base, ch))
        
        shift_pressed = False
        if shift_chars:
            try:
                keyboard.press('shift')
                shift_pressed = True
            except Exception:
                try:
                    pyautogui.keyDown('shift')
                    shift_pressed = True
                except Exception:
                    pass
        

        delay_enabled = self.delay_enabled.get()
        

        for i, (base, original_char) in enumerate(shift_chars):

            if delay_enabled and len(playable_chars) > 1 and i > 0:
                time.sleep(random.uniform(0.010, 0.035))
            
            try:
                keyboard.press(base)
                pressed_list.append({'base': base, 'shift': True, 'pyautogui': False})
            except Exception:
                try:
                    pyautogui.keyDown(base)
                    pressed_list.append({'base': base, 'shift': True, 'pyautogui': True})
                except Exception:
                    pass
        
        if shift_pressed:
            try:
                keyboard.release('shift')
            except Exception:
                try:
                    pyautogui.keyUp('shift')
                except Exception:
                    pass
        
        for i, (base, original_char) in enumerate(normal_chars):

            if delay_enabled and len(playable_chars) > 1 and (i > 0 or len(shift_chars) > 0):
                time.sleep(random.uniform(0.010, 0.035))
            
            try:
                keyboard.press(base)
                pressed_list.append({'base': base, 'shift': False, 'pyautogui': False})
            except Exception:
                try:
                    pyautogui.keyDown(base)
                    pressed_list.append({'base': base, 'shift': False, 'pyautogui': True})
                except Exception:
                    pass
        
        self.held_play_keys[play_key] = {'pressed': pressed_list, 'had_shift': len(shift_chars) > 0}

    def release_held_note_for_playkey(self, play_key):
        held_data = self.held_play_keys.get(play_key)
        if not held_data:
            if play_key in self.held_play_keys:
                del self.held_play_keys[play_key]
            return
        
        if isinstance(held_data, list):
            pressed_list = held_data
        else:
            pressed_list = held_data.get('pressed', [])
            

        delay_enabled = self.delay_enabled.get()
        

        for i, info in enumerate(reversed(pressed_list)):
            base = info.get('base')
            used_py = info.get('pyautogui', False)
            

            if delay_enabled and len(pressed_list) > 1 and i > 0:
                time.sleep(random.uniform(0.010, 0.035))
            
            try:
                if used_py:
                    pyautogui.keyUp(base)
                else:
                    keyboard.release(base)
            except Exception:
                pass
        
        if play_key in self.held_play_keys:
            del self.held_play_keys[play_key]

    def on_play_key_press(self, e):
        if not self.is_playing:
            return
        key_name = e.name
        if key_name in self.held_play_keys:
            return
        
        if self.song_finished:
            self.view_text.config(state=tk.NORMAL)
            self.view_text.delete('1.0', tk.END)
            self.view_text.config(state=tk.DISABLED)
            self.song_finished = False
            self.current_index = 0
            self.note_timestamps = []
            self.nps_label.config(text="0.0 NPS")
            return
        
        current_time = time.time()
        self.note_timestamps.append(current_time)
        
        if len(self.note_timestamps) > self.max_timestamp_count:
            self.note_timestamps.pop(0)
        
        self.update_nps_display()
        
        self.press_and_hold_note_for_playkey(key_name)
        self.current_index += 1
        
        if self.current_index >= len(self.notes):
            self.song_finished = True
        
        self.root.after_idle(self.update_view)

    def on_play_key_release(self, e):
        key_name = e.name
        if key_name in self.held_play_keys:
            self.release_held_note_for_playkey(key_name)

    def toggle_play(self):
        text = self.text_area.get('1.0', tk.END).strip()
        if not text:
            self.view_text.config(state=tk.NORMAL)
            self.view_text.delete('1.0', tk.END)
            self.view_text.insert('1.0', "Please paste notes first!")
            self.view_text.config(state=tk.DISABLED)
            return

        self.notes = self.parse_notes(text)
        if not self.notes:
            self.view_text.config(state=tk.NORMAL)
            self.view_text.delete('1.0', tk.END)
            self.view_text.insert('1.0', "No valid notes found!")
            self.view_text.config(state=tk.DISABLED)
            return

        self.current_index = 0
        self.is_playing = True
        self.held_play_keys = {}
        self.song_finished = False
        self.note_timestamps = []
        self.nps_label.config(text="0.0 NPS")
        self.status_label.config(text="Playing", fg='#4a9eff')
        self.text_area.config(state=tk.DISABLED)
        self.play_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)

        for k in self.play_keys:
            try:
                keyboard.on_press_key(k, self.on_play_key_press, suppress=False)
                keyboard.on_release_key(k, self.on_play_key_release, suppress=False)
            except Exception:
                pass

        self.view_text.config(state=tk.NORMAL)
        self.view_text.delete('1.0', tk.END)
        for i in range(min(10, len(self.notes))):
            note = self.notes[i]
            display_note = f'[{note}]' if len(note) > 1 else note
            self.view_text.insert(tk.END, display_note + ' ')
        self.view_text.config(state=tk.DISABLED)

    def stop(self):
        self.release_all_keys()
        
        self.is_playing = False
        self.held_play_keys = {}
        self.song_finished = False
        self.note_timestamps = []
        self.nps_label.config(text="0.0 NPS")
        self.status_label.config(text="Stopped", fg='#808080')
        self.text_area.config(state=tk.NORMAL)
        self.play_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.view_text.config(state=tk.NORMAL)
        self.view_text.delete('1.0', tk.END)
        self.view_text.config(state=tk.DISABLED)

        try:
            keyboard.unhook_all()
            keyboard.on_press_key('f1', self.on_f1_press, suppress=False)
            keyboard.on_release_key('f1', self.on_f1_release, suppress=False)
            keyboard.on_press_key('f2', self.on_f2_press, suppress=False)
            keyboard.on_release_key('f2', self.on_f2_release, suppress=False)
            keyboard.on_press_key('ctrl', self.on_f1_press, suppress=False) 
            keyboard.on_release_key('ctrl', self.on_f1_release, suppress=False)
            keyboard.on_press_key('alt', self.on_f2_press, suppress=False)
            keyboard.on_release_key('alt', self.on_f2_release, suppress=False)
        except Exception:
            pass

    def on_close(self):
        self.release_all_keys()
        
        try:
            keyboard.unhook_all() 
        except Exception:
            pass
        self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = ManualAutoplayer()
    app.run()